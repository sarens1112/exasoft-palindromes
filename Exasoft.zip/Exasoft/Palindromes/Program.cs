﻿

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Processing Palindromes file...");

        string filePath = "palindromes.txt";
        List<string> palindromes = new List<string>();
        if (File.Exists(filePath))
        {
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                if (StringFunctions.IsPalindrome(line.Trim()))
                {
                    palindromes.Add(line.Trim());
                }
            }
        }

        Console.WriteLine("Palindromes found:");
        foreach (string palindrome in palindromes)
        {
            Console.WriteLine(palindrome);
        }
    }
}
